import 'package:flutter/material.dart';
import 'package:rent/database/database.dart';

class UnknownScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Map<String, dynamic> event = {
      'title': "hell2o",
      "date": DateTime.now().millisecondsSinceEpoch,
    };
    Database().addEvent(event);

    return Scaffold(
      appBar: AppBar(),
      body: Column(
          children: const [
            Center(
              child: Text('Oops something went wrong!'),
            ),
          ]
      ),
    );
  }
}