package com.example.rent

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
